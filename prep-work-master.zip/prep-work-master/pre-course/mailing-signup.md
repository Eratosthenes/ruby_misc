# Mailing List Signup

Once you've been formally sent an offer of acceptance, please sign up
for your cycle's mailing list. **Please don't sign up before you've
been sent an acceptance letter**.

* [2014-12-08 (SF)][2014-12-08-sf]
* [2015-01-19 (NY)][2015-01-19-ny]
* [2015-02-16 (SF)][sf-2015-02-16]
* [2015-03-23 (NY)][2015-03-23-ny]
* [2015-04-20 (SF)][2015-04-20-sf]
* [2015-05-25 (NY)][2015-05-25-ny]
* [2015-06-22 (SF)][2015-06-22-sf]
* [2015-07-27 (NY)][2015-07-27-ny]
* [2015-08-24 (SF)][2015-08-24-sf]
* [2015-09-28 (NY)][2015-09-28-ny]
* [2015-10-26 (SF)][2015-10-26-sf]
* [2016-01-04 (SF)][2016-01-04-sf]

[2014-12-08-sf]: https://groups.google.com/forum/?hl=en#!forum/aa-2014-12-08-sf
[sf-2015-02-16]: https://groups.google.com/forum/?hl=en#!forum/aa-sf-2015-02-16
[2015-01-19-ny]: https://groups.google.com/forum/?hl=en#!forum/aa-2015-01-19-ny
[2015-03-23-ny]: https://groups.google.com/a/appacademy.io/forum/#!forum/2015-03-23-ny
[2015-04-20-sf]: https://groups.google.com/a/appacademy.io/forum/#!forum/2015-04-20-sf
[2015-05-25-ny]: https://groups.google.com/a/appacademy.io/forum/#!forum/2015-05-25-ny
[2015-06-22-sf]: https://groups.google.com/a/appacademy.io/forum/#!forum/2015-06-22-sf
[2015-07-27-ny]: https://groups.google.com/a/appacademy.io/forum/#!forum/2015-07-27-ny
[2015-08-24-sf]: https://groups.google.com/a/appacademy.io/forum/#!forum/2015-08-24-sf
[2015-09-28-ny]: https://groups.google.com/a/appacademy.io/forum/#!forum/2015-09-28-ny
[2015-10-26-sf]: https://groups.google.com/a/appacademy.io/forum/#!forum/2015-10-26-sf
[2016-01-04-sf]: https://groups.google.com/a/appacademy.io/forum/#!forum/2016-01-04-sf
