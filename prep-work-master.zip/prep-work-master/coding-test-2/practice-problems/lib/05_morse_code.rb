def morse_encode(str)
end
