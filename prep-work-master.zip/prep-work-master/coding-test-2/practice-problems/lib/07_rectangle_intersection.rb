def rec_intersection(rect1, rect2)
end
